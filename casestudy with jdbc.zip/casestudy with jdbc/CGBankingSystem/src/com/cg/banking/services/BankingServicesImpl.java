package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices{
	private   static int count=0;
private AccountDAO accountDao=new AccountDAOImpl();
private TransactionDAO transactionDao=new TransactionDAOImpl();
	@Override
	public Account openAccount(String accountType,String accountStatus, float initBalance)
			throws InvalidAccountTypeException, InvalidAccountException, BankingServiceDownException {
		Account account=new Account( accountType,accountStatus,initBalance);
		account=accountDao.save(account);
		
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Your account is blocked");
		else
			account.setAccountBalance(account.getAccountBalance()+amount);
		transactionDao.save((long) accountNo,new Transaction(amount, "Deposit"));
		return account.getAccountBalance();
	}

	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws AccountNotFoundException,
		BankingServiceDownException, InvalidPinNumberException, InsufficientAmountException{
		Account account=getAccountDetails(accountNo);
		
		 if(account.getPinNumber()!=pinNumber)
		 {
			 ++count;
			 if(count==3)account.setAccountStatus("Blocked");
		 }
		 if(account.getAccountBalance()-amount<500)throw new InsufficientAmountException();
		else
			account.setAccountBalance(account.getAccountBalance()-amount);
		transactionDao.save((int)accountNo,new Transaction(amount,"Withdraw"));
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long acccountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServiceDownException, AccountBlockedException {
		Account customerNoTo=getAccountDetails(accountNoTo);
		Account customerNoFrom=getAccountDetails(acccountNoFrom);
		if(customerNoTo.getAccountStatus().equalsIgnoreCase("Blocked")||customerNoFrom.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Account is Blocked");
		else if(customerNoFrom.getPinNumber()!=pinNumber)throw new InvalidPinNumberException("Pin is Invalid");
		else if(customerNoFrom.getAccountBalance()-transferAmount<500)throw new InsufficientAmountException("Amount is Insufficient in Account");
		else {
			customerNoTo.setAccountBalance(customerNoTo.getAccountBalance()+transferAmount);
			customerNoFrom.setAccountBalance(customerNoFrom.getAccountBalance()-transferAmount);
		}
	return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServiceDownException {
		Account account=accountDao.findone(accountNo);
		if(account==null)throw new AccountNotFoundException("Account is not found");
		return account;
	}
@Override
	public List<Account> gaetAllAccountDetails(long accountNo) throws BankingServiceDownException {
		return accountDao.findAll();
	}
	@Override
	public List<Transaction> getAccountAllTransactions(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException {
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServiceDownException, AccountNotFoundException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Account is blocked");
		else
		return "active";
	}

	
}
