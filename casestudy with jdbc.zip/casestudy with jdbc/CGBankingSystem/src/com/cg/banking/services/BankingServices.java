package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface BankingServices {
 Account openAccount(String accountType,String accountStatus,float initBalance)throws InvalidAccountTypeException,
	InvalidAccountException,BankingServiceDownException;
	
	float depositAmount(long accountNo,float amount) throws AccountNotFoundException,BankingServiceDownException,AccountBlockedException;
	
	float withdrawAmount(long accountNo,float amount,int pinNumber)throws InsufficientAmountException, AccountNotFoundException,InvalidPinNumberException,BankingServiceDownException;
	
	boolean fundTransfer(long accountNoTo,long acccountNoFrom,float transferAmount,int pinNumber)throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,BankingServiceDownException,AccountBlockedException;
	
	
	List<Account>gaetAllAccountDetails(long accountNo)throws BankingServiceDownException;
	
	List<Transaction>getAccountAllTransactions(long accountNo)throws BankingServiceDownException,AccountNotFoundException;
	
	public String accountStatus(long accountNo)throws BankingServiceDownException,AccountNotFoundException,AccountBlockedException;

	Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServiceDownException;

	
	

}
