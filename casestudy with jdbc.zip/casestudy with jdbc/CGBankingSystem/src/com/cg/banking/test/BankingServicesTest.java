package com.cg.banking.test;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;
public class BankingServicesTest {

	/*private static BankingServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new BankingServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Account account1=new Account(101, 5000, "Active", "Savings",1234);
		Account account2=new Account(102, 10000, "Blocked", "Savings",2345);
		BankingDBUtil.customer.put(account1.getAccountNo(), account1);
		BankingDBUtil.customer.put(account2.getAccountNo(), account2);
		BankingDBUtil.ACCOUNT_NUMBER=102;
	}
	
//	********************************Deposit*****************************************************
	@Test
	public void testDepositAmountForValidAccountNumber() throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException{
		Account account=new Account(101, 5000, "Active", "Savings",1234);
		account.setAccountBalance(services.depositAmount(account.getAccountNo(), 5000));
		int expectedAmount=(int) account.getAccountBalance();
		int actualAmount=10000;
		Assert.assertEquals(expectedAmount, actualAmount);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidAccountNumber() throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
		services.depositAmount(4554, 5000);
	}
//	*****************************Withdraw***********************************************************
	@Test
	public void testWithdrawAmountForValidAccountNumberAndValidPinNumber() throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, BankingServiceDownException {
		Account account=new Account(101, 5000, "Active", "Savings",1234);
		account.setAccountBalance(services.withdrawAmount(account.getAccountNo(), 2000,account.getPinNumber()));
		int expectedAmount=(int) account.getAccountBalance();
		int actualAmount=3000;
		Assert.assertEquals(expectedAmount, actualAmount);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testWithdrawAmountForInvalidAccountNumberAndValidPinNumber() throws AccountNotFoundException, InsufficientAmountException, InvalidPinNumberException, BankingServiceDownException{
		services.withdrawAmount(5008, 5000, 4545);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForValidAccountNumberAndInvalidPinNumber() throws InvalidPinNumberException, InsufficientAmountException, AccountNotFoundException, BankingServiceDownException{
		services.withdrawAmount(101, 2000,4578);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawAmountForInsufficientAccount()throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, BankingServiceDownException{
		services.withdrawAmount(101, 6000, 1234);
	}
//	*****************************************************************************************************
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountNumber() throws AccountNotFoundException, BankingServiceDownException{
		services.getAccountDetails(12345);
	}
	
	@After
	public void tearDownTestData() {
		BankingDBUtil.customer.clear();
		BankingDBUtil.ACCOUNT_NUMBER=100;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}*/
}