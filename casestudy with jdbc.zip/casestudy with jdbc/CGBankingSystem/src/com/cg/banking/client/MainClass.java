package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;

public class MainClass {

	public static void main(String[] args)  {
		BankingDBUtil.getDBConnection();
		System.out.println("connection is open");
		BankingServices bankingServices=new BankingServicesImpl();
		int accNo = 0,pinNo,accNo2;
		float amount;
		try {
			Account c1=bankingServices.openAccount("Savings ","Active",3000);
			Account c2=bankingServices.openAccount("Savings ","Active", 8000);
		} catch (InvalidAccountTypeException | InvalidAccountException | BankingServiceDownException e) {
			
			e.printStackTrace();
		}
		
		//c1.setAccountStatus("Active");
		
		//c2.setAccountStatus("Active");

			/*System.out.println("Account details :\n"+c1);
			System.out.println("Account details :\n"+c2);

			Scanner sc=new Scanner(System.in);
			int ch;
			do
			{
				System.out.println("1:Withdrawl \n 2: FundTransfer \n 3:Deposit \n 4:Exit");
				ch=sc.nextInt();
				System.out.println("Enter your choice");

				switch(ch)
				{
				case 1:
					System.out.println("*******************WITHDRAWL**************************");
					System.out.println("Enter the accoun number from which money is to be withdrawn");
					accNo=sc.nextInt();
					System.out.println("enter pin number of the account");
					pinNo=sc.nextInt();
					System.out.println("enter amount of money to be withdrawn");
					amount=sc.nextInt();
					try {
						System.out.println(bankingServices.withdrawAmount(accNo,amount,pinNo));
						System.out.println("Account details after withdrawl"+bankingServices.getAccountDetails(accNo));
					} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
							| BankingServiceDownException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
					break;
				case 2:

					System.out.println("********************FUNDTRANSFER********************");
					System.out.println("Enter account number in which money is to be deposited");
					accNo=sc.nextInt();
					System.out.println("Enter account number from which money is to be transfered");
					accNo2 = sc.nextInt();
					System.out.println("enter pin number of the account");
					pinNo=sc.nextInt();
					System.out.println("enter amount of money to be deposited");
					amount=sc.nextInt();
					boolean b = false;
					try {
						b = bankingServices.fundTransfer(accNo, accNo2, amount, pinNo);
					} catch (AccountNotFoundException|AccountBlockedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InsufficientAmountException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvalidPinNumberException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (BankingServiceDownException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(b==true)
					{
						try {
							System.out.println("ACCOUNT DETAILS AFTER TRANSFER"+bankingServices.getAccountDetails(accNo));
							System.out.println(bankingServices.getAccountDetails(accNo2));
						} catch (AccountNotFoundException | BankingServiceDownException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}break;
				case 3:
					System.out.println("*******************DEPOSIT********************");
					System.out.println("Enter account number in which money is to be deposited");
					accNo=sc.nextInt();
					System.out.println("enter amount of money to be deposited");
					amount=sc.nextInt();
					try {
						bankingServices.depositAmount(accNo, amount);
						System.out.println("ACCOUNT details after deposit "+bankingServices.getAccountDetails(accNo));break;
					} catch (AccountNotFoundException e) {

						e.printStackTrace();
					} catch (BankingServiceDownException e) {
					
						e.printStackTrace();
					} catch (AccountBlockedException e) {
						
						e.printStackTrace();
					}
				case 4:System.out.println("Thankyou visit again");
				System.exit(4);
				default:System.out.println("Wrong choice");

				}
		}while(ch!=4);

	}*/
}
}


