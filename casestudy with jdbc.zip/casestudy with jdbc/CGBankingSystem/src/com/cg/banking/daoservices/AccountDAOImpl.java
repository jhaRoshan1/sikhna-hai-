package com.cg.banking.daoservices;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.util.BankingDBUtil;

public class AccountDAOImpl implements AccountDAO{
	private static Connection con=BankingDBUtil.getDBConnection();
	@Override
	public Account save(Account account) {
		try {
			con.setAutoCommit(false);
			PreparedStatement pstm1=con.prepareStatement("insert into account(accountNo,pinNumber,accountType,accountStatus,accountBalance)values(Account_No_SEQ.NEXTVAL,Pin_No_SEQ.NEXTVAL,?,?,?)");
			pstm1.setLong(1, account.getAccountNo());
			pstm1.setInt(2, account.getPinNumber());
			pstm1.setString(3, account.getAccountType());
			pstm1.setString(4, account.getAccountStatus());
			pstm1.setInt(5, account.getAccountBalance());

			pstm1.executeUpdate();

			PreparedStatement pstm2=con.prepareStatement("select max(accountNo)from associate");
			ResultSet rs=pstm2.executeQuery();
			rs.next();
			int accountNo=rs.getInt(1);

			PreparedStatement pstm3=con.prepareStatement("select max(pinNumber)from associate");
			ResultSet rs1=pstm3.executeQuery();
			rs1.next();
			int pinNumber=rs1.getInt(2);

			account.setAccountNo(accountNo);
			account.setPinNumber(pinNumber);
			con.commit();

		} catch (SQLException e) {

			e.printStackTrace();
			try {
				con.rollback();
			}
			catch(SQLException e1) {
				e1.printStackTrace();
			}
		}

		return account;
	}

	@Override
	public boolean update(Account account) {

		return false;
	}

	@Override
	public Account findone(long accountNo) {
		PreparedStatement pstm1;
		try {
			pstm1 = con.prepareStatement("select * from account where accountNo ="+accountNo);
			
			ResultSet accountRs=pstm1.executeQuery();
			if(accountRs.next()) {
				String accountType=accountRs.getString("accountType");
				String accountStatus=accountRs.getString("accountStatus");
				float accountBalance=accountRs.getFloat("accountBalance");
				
				Account account=new Account(accountNo, accountType, accountStatus, (int) accountBalance);
				return account;	
			}
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public List<Account> findAll() {

		return null;
	}


}
