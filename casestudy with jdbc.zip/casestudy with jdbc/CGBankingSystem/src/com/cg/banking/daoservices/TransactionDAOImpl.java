package com.cg.banking.daoservices;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;
import java.util.List;
public class TransactionDAOImpl implements TransactionDAO{
	@Override
	public Transaction findone(int accountNo, int TransactionId) {
		
		return null;
	}

	@Override
	public Transaction save(long accountNo, Transaction transaction) {
		
		return null;
	}

	@Override
	public List<Transaction> findAll(int accountNo) {

		return null;
	}



}
