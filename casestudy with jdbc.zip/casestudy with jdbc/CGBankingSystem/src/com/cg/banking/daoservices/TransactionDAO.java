package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Transaction;

public interface TransactionDAO {
  
	List<Transaction>findAll(int accountNo);
	Transaction findone(int accountNo, int TransactionId);
	Transaction save(long accountNo, Transaction transaction);
}
