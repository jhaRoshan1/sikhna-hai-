package com.cg.payroll.client;

import java.util.Scanner;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayRollDBUtil;

public class MainClass {
	public static void main(String[] args) {		

			Scanner sc=new Scanner(System.in);
			PayrollServices services=new PayrollServicesImpl();
			//int associateId=services.acceptAssociateDetails("roshan", "jha", "java", "analyst", "hwd145", "jharoshan890", 800000, 124578, "icici", "icici1452", 250000, 2000, 3000)	;
			//System.out.println("Associate Id: "+associateId);
			
			
			/*System.out.println("find the associate details you want");
			int num=sc.nextInt();
			try {
				System.out.println(services.getAssociateDetails(num));
			} catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}*/
		System.out.println("all the associate details");
		System.out.println(services.getAllAssociateDetails());
		
		
}
}
