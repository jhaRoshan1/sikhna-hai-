package com.cg.payroll.client;

import com.cg.payroll.util.PayRollDBUtil;

public class CheckMain {

	public static void main(String[] args) {
	PayRollDBUtil.getDBConnection();
	System.out.println("connection is open");
	}

}
